from .fatsecret import Fatsecret, BaseFatsecretError, GeneralError, AuthenticationError, ParameterError,\
    ApplicationError
